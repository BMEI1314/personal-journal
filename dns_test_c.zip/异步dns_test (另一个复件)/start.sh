#!/bin/bash
gcc dnsquery.c test_dns.c -o test
