#!/bin/bash
g++ dnsquery.cc test_dns.cpp -o test
